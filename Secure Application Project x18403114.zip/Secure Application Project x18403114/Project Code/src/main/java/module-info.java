module com.example.secureapplicationprogrammingproject {
    requires javafx.graphics;
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens Sample to javafx.fxml;
    exports Sample;
}