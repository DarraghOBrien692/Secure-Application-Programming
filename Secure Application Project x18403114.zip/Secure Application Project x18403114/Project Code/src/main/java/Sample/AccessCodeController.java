package Sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class AccessCodeController {

    @FXML
    private Button logOutButton;

    @FXML
    private Button submitButton;

    @FXML
    private Label usernameLabel;

    @FXML
    private Label responseLabel;

    @FXML
    private TextField codeTextField;

    public void DisplayName(String username){
        usernameLabel.setText(username);
    }

    public void logOutButton(ActionEvent event){
        try{
            Stage stage = (Stage) logOutButton.getScene().getWindow();
            stage.close();

            Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
            Stage registerStage = new Stage();
            registerStage.initStyle(StageStyle.UNDECORATED);
            registerStage.setScene(new Scene(root, 600, 400));
            registerStage.show();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void submitButton(ActionEvent event){
        if(codeTextField.getText().isBlank()){
            responseLabel.setText("Please enter your access code before submitting");
        }
        else{
            // Get connection to the database
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();

            // Get variable being submitted
            String username = usernameLabel.getText();

            // rs1
            // Select accessCode from user_account where username = '1'
            String selectFields1 = "Select accessCode from user_account where username = '";
            String selectValues1 = username + "'";
            String QueryCheck = selectFields1 + selectValues1;

            try {
                Statement statement = connectDB.createStatement();
                statement.executeQuery(QueryCheck);

                ResultSet rs1 = statement.executeQuery(QueryCheck);

                if(rs1.next()){
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("message.fxml"));
                    Parent root = loader.load();

                    MessageController messageController = loader.getController();
                    messageController.DisplayName(username);

                    Stage stage = (Stage) submitButton.getScene().getWindow();
                    stage.close();

                    Stage registerStage = new Stage();
                    registerStage.initStyle(StageStyle.UNDECORATED);
                    registerStage.setScene(new Scene(root, 600, 400));
                    registerStage.show();
                }
                else{
                    responseLabel.setText("That is the incorrect Access Code.");
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                e.getCause();
            }
        }
    }
}
