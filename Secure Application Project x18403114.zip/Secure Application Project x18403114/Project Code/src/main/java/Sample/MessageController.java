package Sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class MessageController {

    @FXML
    private Button logoutButton;

    @FXML
    private Button deleteMessageButton;

    @FXML
    private TextField messageTextField;

    @FXML
    private Label resultLabel;

    @FXML
    private Label messageLabel;

    @FXML
    private Label usernameLabel2;

    // Set usernameLabel2 to display the username + set messageLabel to display the users message
    public void DisplayName(String username){
        usernameLabel2.setText(username);

        // Get connection to the database
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        // Get variables
        String username2 = usernameLabel2.getText();

        // Select message from user_account where user = '';
        String insertField = "Select message from user_account where username = '";
        String insertValue = username2 + "'";

        String insertToGrab = insertField + insertValue;

        try {
            Statement statement = connectDB.createStatement();
            statement.executeQuery(insertToGrab);

            ResultSet rs1 = statement.executeQuery(insertToGrab);

            if(rs1.next()) {
                messageLabel.setText(rs1.getString(1));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }
    }
    // Return to the login screen
    public void logoutButton(ActionEvent event){
        try {
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.close();

            Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
            Stage registerStage = new Stage();
            registerStage.initStyle(StageStyle.UNDECORATED);
            registerStage.setScene(new Scene(root, 600, 400));
            registerStage.show();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    // Change the message stored in the database for the user
    public void changeMessageButton(ActionEvent event){
        if(messageTextField.getText().isBlank()){
            resultLabel.setText("Please enter a message into the text field.");
        }
        else{
            // Get connection to the database
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();

            // Get variables
            String username = usernameLabel2.getText();
            String message = messageTextField.getText();

            // Update user_account set message = null where username = ' ';
            String insertField1 = "Update user_account set message = '";
            String insertValue1 = message + "'";
            String insertField2 = " where username = '";
            String insertValue2 = username + "'";
            String insertToUpdate = insertField1 + insertValue1 + insertField2 + insertValue2;

            try {
                Statement statement = connectDB.createStatement();
                statement.executeUpdate(insertToUpdate);

                messageLabel.setText(message);
                resultLabel.setText("Message has been successfully changed.");
            }
            catch (Exception e) {
                e.printStackTrace();
                e.getCause();
            }
        }
    }
    // Remove the message from the database for the user
    public void deleteMessageButton(ActionEvent event){
        if(messageTextField.getText().isBlank()){
            resultLabel.setText("There is no message to delete");
        }
        else {
            messageLabel.setText("");

            // Get connection to the database
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();

            // Get variables
            String username = usernameLabel2.getText();

            // Update user_account set message = null where username = '4';
            String insertFields = "Update user_account set message = null where username = '";
            String insertValues = username + "'";
            String insertToDelete = insertFields + insertValues;

            try {
                Statement statement = connectDB.createStatement();
                statement.executeUpdate(insertToDelete);

                resultLabel.setText("Message has been successfully deleted");
            } catch (Exception e) {
                e.printStackTrace();
                e.getCause();
            }
        }
    }
}
