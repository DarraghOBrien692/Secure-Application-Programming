package Sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.stage.StageStyle;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginController{
    @FXML
    private Button loginButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Label loginMessageLabel;
    @FXML
    TextField usernameTextField;
    @FXML
    private PasswordField enterPasswordField;

    // Submit username and password for validation to enter Access Code page
    public void loginButton(ActionEvent event){
        // If the username field and password field are filled
        if(usernameTextField.getText().isBlank() == false && enterPasswordField.getText().isBlank() == false){
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();

            // Verify if there is a matching username and password
            String verifyLogin = "SELECT count(1) FROM user_account WHERE username = '" + usernameTextField.getText() + "' AND password ='" + enterPasswordField.getText() + "'";

            try{
                Statement statement = connectDB.createStatement();
                ResultSet queryResult = statement.executeQuery(verifyLogin);

                while(queryResult.next()){
                    // If there is a valid result, open the Access Code page
                    if(queryResult.getInt(1) == 1){
                        try{
                            String username = usernameTextField.getText();
                            FXMLLoader loader = new FXMLLoader(getClass().getResource("accessCode.fxml"));
                            Parent root = loader.load();

                            AccessCodeController accessCodeController = loader.getController();
                            accessCodeController.DisplayName(username);

                            Stage stage = (Stage) loginButton.getScene().getWindow();
                            stage.close();

                            Stage registerStage = new Stage();
                            registerStage.initStyle(StageStyle.UNDECORATED);
                            registerStage.setScene(new Scene(root, 600, 400));
                            registerStage.show();
                        }
                        catch(Exception e){
                            e.printStackTrace();
                            e.getCause();
                        }
                    }
                    // If there is not a valid result, display error message
                    else{
                        loginMessageLabel.setText("Invalid Login, please try again.");
                    }
                }
            }
            catch (Exception e){
                e.printStackTrace();
                e.getCause();
            }
        }
        // If the username field and password field are empty
        else{
            loginMessageLabel.setText("Please enter a username and password");
        }
    }
    // Go to the password Recovery Page
    public void passwordRecoveryButton(ActionEvent event){
        try{
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            stage.close();

            Parent root = FXMLLoader.load(getClass().getResource("passwordRecovery.fxml"));
            Stage registerStage = new Stage();
            registerStage.initStyle(StageStyle.UNDECORATED);
            registerStage.setScene(new Scene(root, 600, 400));
            registerStage.show();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    // Go to the Entrance Page
    public void cancelButton(ActionEvent event){
        try{
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            stage.close();

            Parent root = FXMLLoader.load(getClass().getResource("entrance.fxml"));
            Stage registerStage = new Stage();
            registerStage.initStyle(StageStyle.UNDECORATED);
            registerStage.setScene(new Scene(root, 600, 400));
            registerStage.show();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}