package Sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class RegisterController {
    @FXML
    private Button cancelButton;
    @FXML
    private Label registrationResultLabel;
    @FXML
    private PasswordField passwordField;
    @FXML
    private PasswordField confirmPasswordField;
    @FXML
    private TextField firstNameTextField;
    @FXML
    private TextField lastNameTextField;
    @FXML
    private TextField usernameTextField;
    @FXML
    private TextField securityQuestionTextField;
    @FXML
    private TextField securityAnswerPasswordField;
    @FXML
    private TextField accessCodePasswordField;

    // Register information with the applications database
    public void registerButton(ActionEvent event){
        // If not all fields have a value
        if (firstNameTextField.getText().trim().isEmpty() || lastNameTextField.getText().trim().isEmpty() || usernameTextField.getText().trim().isEmpty()
                || passwordField.getText().trim().isEmpty() || confirmPasswordField.getText().trim().isEmpty() || securityQuestionTextField.getText().trim().isEmpty()
                || securityAnswerPasswordField.getText().trim().isEmpty() || accessCodePasswordField.getText().trim().isEmpty()) {
            // Notify the user that a field is blank
            registrationResultLabel.setText("User has not been registered, please fill in all fields to register.");
        }
        else if(!passwordField.getText().equals(confirmPasswordField.getText())){
            registrationResultLabel.setText("User has not been registered, passwords do match.");
        }
        // If all fields have a value
        else{
            // Check if the username has already been registered
                checkUsername();
        }
    }
    // Check if the Username is taken
    public void checkUsername(){
        // Checking if there is already a username in the database
            // Get connection to the database
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();

            String username = usernameTextField.getText();

            String selectFields = "SELECT username from user_account where username = '";
            String selectValues = username + "'";
            String QueryCheck = selectFields + selectValues;

            try {
                Statement statement = connectDB.createStatement();
                statement.executeQuery(QueryCheck);

                ResultSet rs = statement.executeQuery(QueryCheck);

                if(rs.next()){
                    registrationResultLabel.setText("User has not been registered, there is already an account with this username.");
                }
                else{
                    registerUser();
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                e.getCause();
            }
    }

    // Creating an account for the user
    public void registerUser(){

        // Get connection to the database
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        // Get variables
        String firstName = firstNameTextField.getText();
        String lastname = lastNameTextField.getText();
        String username = usernameTextField.getText();
        String password = passwordField.getText();
        String securityQuestion = securityQuestionTextField.getText();
        String securityAnswer = securityAnswerPasswordField.getText();
        String accessCode = accessCodePasswordField.getText();

        // Insert the variables into the database

        String insertFields = "INSERT INTO user_account (firstName, lastName, username, password, securityQuestion, securityAnswer, accessCode) VALUES ('";
        String insertValues = firstName + "','" + lastname + "','" + username + "','" + password + "','" + securityQuestion + "','" + securityAnswer + "','" + accessCode + "')";
        String insertToRegister = insertFields + insertValues;


        try {
            Statement statement = connectDB.createStatement();
            statement.executeUpdate(insertToRegister);

            registrationResultLabel.setText("User has been registered successfully.");
        }
        catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }
    }

    // Return to the entrance page
    public void cancelButton(ActionEvent event){
        try{
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            stage.close();

            Parent root = FXMLLoader.load(getClass().getResource("entrance.fxml"));
            Stage registerStage = new Stage();
            registerStage.initStyle(StageStyle.UNDECORATED);
            registerStage.setScene(new Scene(root, 600, 400));
            registerStage.show();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}
