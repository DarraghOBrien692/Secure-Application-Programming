package Sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class PasswordRecoveryController {

    @FXML
    private Button cancelButton;
    @FXML
    private TextField usernameTextField;
    @FXML
    private TextField securityAnswerTextfield;
    @FXML
    private Label resultLabel;
    @FXML
    private Label securityQuestionLabel;

    // Submit username and get security question
    public void usernameButton(ActionEvent event){
        // If usernameTextField is blank
        if(usernameTextField.getText().isBlank()){
            resultLabel.setText("Please enter a username into the text field.");
        }
        // Else
        else{
            // Get connection to the database
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();

            // Get variable being submitted
            String username = usernameTextField.getText();

            // rs1
            String selectFields1 = "SELECT * from user_account where username = '";
            String selectValues1 = username + "'";
            String QueryCheck = selectFields1 + selectValues1;

            try {
                Statement statement = connectDB.createStatement();
                statement.executeQuery(QueryCheck);

                ResultSet rs1 = statement.executeQuery(QueryCheck);

                if(rs1.next()){
                        securityQuestionLabel.setText(rs1.getString(6));
                        resultLabel.setText("");
                }
                else{
                    securityQuestionLabel.setText("");
                    resultLabel.setText("This username does not exist in our database.");
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                e.getCause();
            }
        }
    }

    // Submit security answer and get password
    public void submitButton(ActionEvent event){
        if(securityAnswerTextfield.getText().isBlank()){
            resultLabel.setText("Please enter an answer into the text field.");
        }
        else{
            // Get connection to the database
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();

            // Get variable being submitted
            String username = usernameTextField.getText();
            String securityAnswer = securityAnswerTextfield.getText();

            // rs1
            String selectFields1 = "SELECT * from user_account where username = '";
            String selectValues1 = username + "'";
            String QueryCheck = selectFields1 + selectValues1;

            try {
                Statement statement = connectDB.createStatement();
                statement.executeQuery(QueryCheck);

                ResultSet rs1 = statement.executeQuery(QueryCheck);

                if(rs1.next()){
                    resultLabel.setText("That is the correct answer, here is your password: " + rs1.getString(5));
                }
                else{
                    securityAnswerTextfield.setText("");
                    resultLabel.setText("That is the incorrect answer.");
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                e.getCause();
            }
        }
    }

    // Return to Login Page
    public void cancelButton(ActionEvent event){
        try{
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            stage.close();

            Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
            Stage registerStage = new Stage();
            registerStage.initStyle(StageStyle.UNDECORATED);
            registerStage.setScene(new Scene(root, 600, 400));
            registerStage.show();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}
